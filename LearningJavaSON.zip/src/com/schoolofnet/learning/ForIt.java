package com.schoolofnet.learning;

public class ForIt {
//	public static void main(String[] args) {
//		for (int i = 0; i <= 30; i++) {
//			if ((i % 3) == 0) {
//				System.out.println("teste");
//			}
//		
//		}
//	}
}
