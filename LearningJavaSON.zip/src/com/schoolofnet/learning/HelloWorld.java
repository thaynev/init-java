package com.schoolofnet.learning;

public class HelloWorld {
	
	//Attribute
	public static String myAttr = "Attr";
	
	/*
	 * public static void main(String[] args) { myAttr = ""; // this.myAttr = "";
	 * 
	 * //primitivo int myInt = 0; char myChar = 'C'; byte myByte; float myFloat = 0;
	 * double myDouble = 0.0;
	 * 
	 * //wrapper Integer myIntW = null; Character myCharW = 'C'; Byte myByteW =
	 * null; Float myFloatW = null; Double myDoubleW = null; String myStrW = "Str";
	 * 
	 * System.out.println("Hello World"); }
	 */
}
