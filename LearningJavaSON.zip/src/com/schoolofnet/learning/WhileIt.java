package com.schoolofnet.learning;

public class WhileIt {
//	public static void main(String[] args) {
//		Integer counter = 0;
//		
////		while (counter <= 27) {
////			System.out.println(counter);
////			counter++;
////		}
//		
//		do {
//			System.out.println(counter);
//			counter++;
//		} while(counter <= 27);
//	}
}
